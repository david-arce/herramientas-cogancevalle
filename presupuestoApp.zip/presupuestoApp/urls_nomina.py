"""
Rutas del presupuesto de nómina.

En el urls.py de la app:
    from .urls_nomina import urlpatterns as urls_nomina
    urlpatterns += urls_nomina

y borrar las ~150 rutas viejas de nómina (sueldos, tabla_auxiliar_*, guardar_*,
guardar_*_temp, subir_presupuesto_*, borrar_presupuesto_*, cargar_*_base,
obtener_*_temp, obtener_presupuesto_*, exportar_excel, exportar_nomina_vertical,
presupuestoNomina).
"""
from django.urls import path

from . import views_nomina as v

urlpatterns = [
    path('nomina/', v.presupuestoNomina, name='presupuestoNomina'),
    path('nomina/recalcular/', v.nomina_recalcular_todo, name='nomina_recalcular_todo'),
    path('nomina/resumen/', v.nomina_resumen, name='nomina_resumen'),
    path('nomina/exportar/', v.exportar_excel_nomina, name='exportar_excel'),
    path('nomina/exportar-vertical/', v.exportar_nomina_vertical, name='exportar_nomina_vertical'),

    # Datos de origen (van antes de <slug:tipo> para que no se confundan)
    path('nomina/origen/subir/', v.nomina_origen_subir, name='nomina_origen_subir'),
    path('nomina/origen/configurar/', v.nomina_origen_config, name='nomina_origen_config'),
    path('nomina/origen/borrar/', v.nomina_origen_borrar, name='nomina_origen_borrar'),
    path('nomina/origen/plantilla/', v.nomina_origen_plantilla, name='nomina_origen_plantilla'),
    path('nomina/origen/<int:anio>/exportar/', v.nomina_origen_exportar, name='nomina_origen_exportar'),
    path('nomina/recargar-bases/', v.nomina_recargar_bases, name='nomina_recargar_bases'),
    path('nomina/distribucion/', v.nomina_distribucion, name='nomina_distribucion'),
    path('nomina/distribucion/aplicar/', v.nomina_distribucion_aplicar, name='nomina_distribucion_aplicar'),
    path('nomina/distribucion/quitar/', v.nomina_distribucion_quitar, name='nomina_distribucion_quitar'),

    # <tipo> = sueldos, comisiones, cesantias, ... o "todos" (vista consolidada)
    path('nomina/<slug:tipo>/', v.nomina_tabla, name='nomina_tabla'),
    path('nomina/<slug:tipo>/datos/', v.nomina_datos, name='nomina_datos'),
    path('nomina/<slug:tipo>/guardar/', v.nomina_guardar, name='nomina_guardar'),
    path('nomina/<slug:tipo>/cargar/', v.nomina_cargar, name='nomina_cargar'),
    path('nomina/<slug:tipo>/borrar/', v.nomina_borrar, name='nomina_borrar'),
]
